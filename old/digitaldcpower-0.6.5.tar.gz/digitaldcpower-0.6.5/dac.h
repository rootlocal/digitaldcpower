/* vim: set sw=8 ts=8 si : */
#ifndef DAC_H
#define DAC_H

extern void init_dac(void);
// set a value:
extern void dac(uint16_t value);

#endif 
