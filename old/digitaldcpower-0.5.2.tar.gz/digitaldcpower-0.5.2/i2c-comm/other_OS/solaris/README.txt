These are binaries for solaris. The source code is
the same as for linux (there are some compatibility
defines in the linux sources).

This software was compiled for
SunOS 5.8
