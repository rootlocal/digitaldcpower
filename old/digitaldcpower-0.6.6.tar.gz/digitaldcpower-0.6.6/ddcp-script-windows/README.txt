The code is written for 32-bit windows and was tested with
windows XP. It works also for other versions of windows.
However you might have to re-compile. In any case you can try
the pre-compiled binaries and see if they work even if you
do not run Win XP.

The code compiles with MinGW and MSYS (see http://www.mingw.org/).

Older versions of MSYS are available as install packages and
a bit easier the handle.


