This is a port of the command line tools i2ctalk and
i2c_rs232_pintest to windows.

Feel free to take the code and wrap it in a nice
GUI if you want something more "windows" like ;-)

The code is written for 32-bit windows and was tested with
windows 98 and windows 2000. It works probably also for other
systems.

The code compiles with MinGW and MSYS (see http://www.mingw.org/).
